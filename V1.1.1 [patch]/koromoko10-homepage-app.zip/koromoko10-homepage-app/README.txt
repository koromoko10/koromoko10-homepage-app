1) Extract the whole zip

2) Open "koromoko10-homepage-app.exe" to start the app.

Open "licenses.html" for information regarding open source software used by the app.