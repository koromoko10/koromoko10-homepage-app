#!/bin/bash
cd "$(dirname "$0")"
./Linux_koromoko-homepage-app